def hello():
    print('im lazy')